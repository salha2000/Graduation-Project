import 'package:car/utils/assets.dart';
import 'package:car/view/auth/select_user_type_view.dart';
import 'package:car/view/widgets/custom_loader.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import 'core/view_model/loader.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await GetStorage.init();

  // await Firebase.initializeApp().then((_) {
  //   FirebaseFirestore.instance.settings =
  //       const Settings(persistenceEnabled: false);
  // });

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: ScreenUtilInit(
        designSize: const Size(375, 812),
        builder: (context, _) {
          return Stack(
            children: [
              GetMaterialApp(
                // initialBinding: Binding(),
                debugShowCheckedModeBanner: false,
                title: "Car",
                theme: ThemeData(
                  primaryColor: Assets.shared.primaryColor,
                  scaffoldBackgroundColor:
                      Assets.shared.scaffoldBackgroundColor,
                  visualDensity: VisualDensity.adaptivePlatformDensity,
                  colorScheme: ColorScheme.fromSwatch().copyWith(
                    secondary: Assets.shared.secondaryColor,
                  ),
                  appBarTheme: const AppBarTheme(
                    backgroundColor: Colors.transparent,
                    elevation: 0,
                  ),
                  fontFamily: Assets.shared.primaryFont,
                  textSelectionTheme: TextSelectionThemeData(
                    cursorColor: Assets.shared.primaryColor,
                  ),
                ),
                home: const SelectUserTypeView(),
              ),
              GetBuilder<LoaderViewModel>(
                init: LoaderViewModel(),
                builder: (controller) {
                  return Visibility(
                    visible: controller.isActiveLoader,
                    child: const CustomLoader(),
                  );
                },
              ),
            ],
          );
        },
      ),
    );
  }
}
