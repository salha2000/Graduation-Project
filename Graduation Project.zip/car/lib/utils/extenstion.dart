import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../core/view_model/loader.dart';

extension StringExtensions on String {
  bool isValidEmail() => RegExp(
          r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
      .hasMatch(this);

  bool isValidPassword() => length >= 6 && length <= 15;
  
}

extension DateTimeExtensions on DateTime {
  String convertToDateStringOnly() => "$year - $month - $day";
}

extension CustomExtenstionGetInterface on GetInterface {
  void customSnackbar({
    required String title,
    required String message,
    bool isError = false,
  }) {
    Get.snackbar(
      title,
      message,
      backgroundColor: isError ? Colors.red : Colors.green,
      colorText: Colors.white,
    );
  }

  void customLoader({bool isShowLoader = true}) async {
    await Future.delayed(const Duration(milliseconds: 100));

    Get.put(LoaderViewModel()).showLoader(isShowLoader: isShowLoader);
  }
}
