import 'package:flutter/material.dart';

const String _imagesPath = "assets/images/";

const String _iconsPath = "${_imagesPath}icons/";

class Assets {
  static final shared = Assets();

  // TODO: - Colors

  final Color primaryColor = const Color(0xff7A4799);

  final Color secondaryColor = const Color(0xffD9D9D9);

  final Color emptyColor = const Color(0xffa09d9d);

  final Color scaffoldBackgroundColor = const Color(0xffefe9f2);

  // TODO: - Fonts

  final String primaryFont = 'NeoSansArabic';

  // TODO: - Icons

  final String icLogo = "${_iconsPath}ic_logo.png";

  // TODO: - Images

  final String bgSplash = "${_imagesPath}bg_splash.png";

}