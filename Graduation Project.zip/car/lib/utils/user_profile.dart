// import 'dart:developer';
//
// import 'package:get_storage/get_storage.dart';
//
// import '../model/user_model.dart';
// import 'enums/language.dart';
//
// class UserProfile {
//   static final shared = UserProfile();
//
//   final _box = GetStorage();
//
//   UserModel? currentUser;
//
//   Language currentLanguage = Language.arabic;
//
//   Future<bool?> getIsFirstOpenApp() async {
//     try {
//       return _box.read('is-first-open-app');
//     } catch (e) {
//       return null;
//     }
//   }
//
//   setIsFirstOpenApp({required bool value}) async {
//     try {
//       await _box.write('is-first-open-app', value);
//     } catch (e) {
//       log(e.toString());
//     }
//   }
//
//   Future<UserModel?> getUser() async {
//     try {
//       return _box.read('current-user') == ""
//           ? null
//           : userModelFromJson(_box.read('current-user'));
//     } catch (e) {
//       return null;
//     }
//   }
//
//   setUser({required UserModel? user}) async {
//     try {
//       if (user == null) {
//         _box.remove('current-user');
//         currentUser = null;
//         return;
//       }
//
//       await _box.write('current-user', userModelToJson(user));
//     } catch (e) {
//       log(e.toString());
//     }
//   }
//
//   Future<Language?> getLanguage() async {
//     try {
//       Language? lang = _box.read('language') == null
//           ? null
//           : Language.values[_box.read('language')];
//
//       currentLanguage = lang ?? Language.arabic;
//
//       return lang;
//     } catch (e) {
//       return null;
//     }
//   }
//
//   setLanguage({required Language lang}) async {
//     try {
//       await _box.write('language', lang.index);
//     } catch (e) {
//       log(e.toString());
//     }
//   }
// }