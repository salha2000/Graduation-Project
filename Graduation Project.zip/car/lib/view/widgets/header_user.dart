import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'custom_text.dart';

class HeaderUser extends StatelessWidget {
  const HeaderUser({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          children: [
            const CustomText(
              text: "Hello [User Name]",
              textColor: Color(0xff474747),
              fontWeight: FontWeight.bold,
              fontStyle: FontStyle.italic,
              fontSize: 15,
            ),
            SizedBox(
              height: 10.h,
            ),
            const CustomText(
              text: "[Sub Title]",
              textColor: Color(0xff747474),
              fontWeight: FontWeight.bold,
              fontStyle: FontStyle.italic,
              fontSize: 9,
            ),
          ],
        ),
        Container(
          width: 50.r,
          height: 50.r,
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: const Color(0xff304FFE),
              )),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Icon(
                Icons.person,
                size: 28.r,
                color: const Color(0xff747474),
              ),
            ],
          ),
        ),
      ],
    );
  }
}