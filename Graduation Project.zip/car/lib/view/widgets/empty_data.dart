import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'custom_text.dart';

class EmptyData extends StatelessWidget {
  final String? image;

  final String? title;

  const EmptyData({Key? key, this.image, this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          image ?? "",
          width: 150.r,
          height: 150.r,
        ),
        SizedBox(
          height: 20.h,
        ),
        CustomText(
          text: title ?? "",
          textColor: Colors.black38,
        ),
      ],
    );
  }
}
