import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../utils/assets.dart';
import 'custom_text.dart';

class CustomAuthTextField extends StatelessWidget {
  const CustomAuthTextField({
    Key? key,
    required this.hintText,
    this.label,
    this.initialValue,
    this.textInputType = TextInputType.text,
    this.textInputAction = TextInputAction.done,
    this.isPassword = false,
    this.maxLine,
    this.isReadOnly,
    this.onTab,
    required this.onSaved,
  }) : super(key: key);

  final String hintText;
  final String? label;
  final String? initialValue;
  final TextInputType textInputType;
  final TextInputAction textInputAction;
  final Function(String?) onSaved;
  final bool isPassword;
  final int? maxLine;
  final bool? isReadOnly;
  final VoidCallback? onTab;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Visibility(
          visible: label != null,
          child: Column(
            children: [
              CustomText(
                text: label ?? "",
                alignment: Alignment.centerLeft,
                textAlign: TextAlign.start,
                fontWeight: FontWeight.bold,
                textColor: Assets.shared.primaryColor,
                fontSize: 14,
              ),
              SizedBox(
                height: 16.h,
              ),
            ],
          ),
        ),
        TextFormField(
          controller: initialValue == null
              ? null
              : TextEditingController(text: initialValue),
          textInputAction: textInputAction,
          keyboardType: textInputType,
          onSaved: (value) => onSaved(value),
          obscureText: isPassword,
          readOnly: isReadOnly ?? false,
          maxLines: maxLine ?? 1,
          decoration: InputDecoration(
            border: InputBorder.none,
            hintText: hintText,
            hintStyle: const TextStyle(
              fontWeight: FontWeight.bold,
              color: Color(0xffd9d9d9),
            ),
            filled: true,
            fillColor: Colors.white,
          ),
        ),
      ],
    );
  }
}