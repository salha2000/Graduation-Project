import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../utils/assets.dart';
import 'custom_text.dart';

class MainButton extends StatelessWidget {
  final String title;
  final FontWeight? fontWeight;
  final FontStyle? fontStyle;
  final VoidCallback onPressed;

  const MainButton({
    Key? key,
    required this.title,
    required this.onPressed,
    this.fontWeight,
    this.fontStyle,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xffd9d9d9),
        padding: EdgeInsets.symmetric(vertical: 12.r, horizontal: 30.w,),
      ).copyWith(
        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(25.r)),
          ),
        ),
      ),
      child: CustomText(
        text: title.toUpperCase(),
        textColor: Assets.shared.primaryColor,
        fontWeight: fontWeight ?? FontWeight.bold,
        fontStyle: fontStyle ?? FontStyle.normal,
      ),
    );
  }
}