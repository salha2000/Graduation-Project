import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

class ImageNetworkCached extends StatelessWidget {
  final String imageUrl;
  final BoxFit fit;

  const ImageNetworkCached({
    Key? key,
    required this.imageUrl,
    this.fit = BoxFit.cover,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CachedNetworkImage(
      imageUrl: imageUrl,
      fit: fit,
      progressIndicatorBuilder: (context, url, downloadProgress) => Container(
        color: Colors.grey.shade300,
        child: const Center(
          child: Icon(
            Icons.image,
            color: Colors.grey,
          ),
        ),
      ),
      // progressIndicatorBuilder: (context, url, downloadProgress) => Center(
      //   child: CircularProgressIndicator(value: downloadProgress.progress),
      // ),
      errorWidget: (context, url, error) => Container(
        color: Colors.grey.shade300,
        child: const Center(
          child: Icon(
            Icons.error,
            color: Colors.grey,
          ),
        ),
      ),
    );
  }
}
