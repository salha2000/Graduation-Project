import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../utils/assets.dart';

class IconBack extends StatelessWidget {
  const IconBack({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Container(
        padding: EdgeInsets.fromLTRB(10.r, 5.r, 5.r, 5.r),
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          color: Color(0xffd9d9d9),
        ),
        child: Icon(Icons.arrow_back_ios, color: Assets.shared.primaryColor,),
      ),
      onPressed: () => Navigator.of(context).pop(),
    );
  }
}