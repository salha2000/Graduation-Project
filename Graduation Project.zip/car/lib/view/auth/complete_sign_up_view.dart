import 'package:car/utils/assets.dart';
import 'package:car/view/widgets/custom_auth_text_field.dart';
import 'package:car/view/widgets/custom_text.dart';
import 'package:car/view/widgets/main_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../widgets/icon_back.dart';

class CompleteSignUpView extends StatelessWidget {
  const CompleteSignUpView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const IconBack(),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.r),
        child: Column(
          children: [
            SizedBox(
              height: 60.h,
            ),
            Form(
              child: Column(
                children: [
                  SizedBox(
                    height: 36.h,
                  ),
                  CustomAuthTextField(
                    label: "the age",
                    hintText: "must be form 25 to 40 years old",
                    onSaved: (String? value) {},
                    textInputAction: TextInputAction.next,
                    textInputType: const TextInputType.numberWithOptions(),
                  ),
                  SizedBox(
                    height: 30.h,
                  ),
                  CustomAuthTextField(
                    label: "Country",
                    hintText: "saudi arabia",
                    onSaved: (String? value) {},
                    textInputAction: TextInputAction.next,
                  ),
                  SizedBox(
                    height: 30.h,
                  ),
                  CustomAuthTextField(
                    label: "National Identity",
                    hintText: "1109****",
                    onSaved: (String? value) {},
                    textInputType: const TextInputType.numberWithOptions(),
                    textInputAction: TextInputAction.next,
                  ),
                  SizedBox(
                    height: 30.h,
                  ),
                  CustomAuthTextField(
                    label: "the age of the car",
                    hintText: "Must not be less than 2016",
                    onSaved: (String? value) {},
                    textInputType: const TextInputType.numberWithOptions(),
                    textInputAction: TextInputAction.done,
                  ),
                  SizedBox(
                    height: 55.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      MainButton(
                        title: "Sign Up",
                        onPressed: () {},
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 55.h,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}