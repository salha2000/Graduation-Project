import 'package:car/utils/assets.dart';
import 'package:car/view/auth/complete_sign_up_view.dart';
import 'package:car/view/widgets/custom_auth_text_field.dart';
import 'package:car/view/widgets/custom_text.dart';
import 'package:car/view/widgets/main_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import '../widgets/icon_back.dart';

class SignUpView extends StatelessWidget {
  const SignUpView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const IconBack(),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.r),
        child: Column(
          children: [
            SizedBox(
              height: 60.h,
            ),
            CustomText(
              text: "Welcome to the kids delivery app :)",
              textColor: Assets.shared.primaryColor,
              fontWeight: FontWeight.bold,
              alignment: Alignment.centerLeft,
            ),
            Form(
              child: Column(
                children: [
                  SizedBox(
                    height: 36.h,
                  ),
                  CustomAuthTextField(
                    label: "Enter your name",
                    hintText: "First name & Last name",
                    onSaved: (String? value) {},
                    textInputAction: TextInputAction.next,
                  ),
                  SizedBox(
                    height: 30.h,
                  ),
                  CustomAuthTextField(
                    label: "Enter your email",
                    hintText: "xxxxxx@gmail.com",
                    onSaved: (String? value) {},
                    textInputType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.next,
                  ),
                  SizedBox(
                    height: 30.h,
                  ),
                  CustomAuthTextField(
                    label: "Enter your phone number",
                    hintText: "+966",
                    onSaved: (String? value) {},
                    textInputType: TextInputType.phone,
                    textInputAction: TextInputAction.next,
                  ),
                  SizedBox(
                    height: 30.h,
                  ),
                  CustomAuthTextField(
                    label: "Enter your password",
                    hintText: "Please enter strong password",
                    onSaved: (String? value) {},
                    isPassword: true,
                    textInputAction: TextInputAction.next,
                  ),
                  SizedBox(
                    height: 30.h,
                  ),
                  CustomAuthTextField(
                    label: "Enter your password again",
                    hintText: "Please enter  password again",
                    onSaved: (String? value) {},
                    isPassword: true,
                    textInputAction: TextInputAction.done,
                  ),
                  SizedBox(
                    height: 55.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      MainButton(
                        title: "Sign Up",
                        onPressed: () => Get.to(() => const CompleteSignUpView()),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 55.h,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}