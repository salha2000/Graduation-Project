import 'package:car/utils/assets.dart';
import 'package:car/view/auth/sign_up_view.dart';
import 'package:car/view/widgets/custom_auth_text_field.dart';
import 'package:car/view/widgets/custom_text.dart';
import 'package:car/view/widgets/main_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import '../widgets/icon_back.dart';

class SignInView extends StatelessWidget {
  const SignInView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const IconBack(),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.r),
        child: Column(
          children: [
            SizedBox(
              height: 60.h,
            ),
            CustomText(
              text: "Welcome Back :)",
              textColor: Assets.shared.primaryColor,
              fontWeight: FontWeight.bold,
              alignment: Alignment.centerLeft,
            ),
            Form(
              child: Column(
                children: [
                  SizedBox(
                    height: 36.h,
                  ),
                  CustomAuthTextField(
                    hintText: "Enter email",
                    onSaved: (String? value) {},
                    textInputType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.next,
                  ),
                  SizedBox(
                    height: 50.h,
                  ),
                  CustomAuthTextField(
                    hintText: "Enter Password",
                    onSaved: (String? value) {},
                    isPassword: true,
                    textInputAction: TextInputAction.done,
                  ),
                  SizedBox(
                    height: 82.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      MainButton(
                        title: "join",
                        onPressed: () {},
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 172.h,
            ),
            CustomText(
              text: "You don’t have account ?",
              textColor: Assets.shared.primaryColor,
              fontWeight: FontWeight.bold,
            ),
            SizedBox(
              height: 16.h,
            ),
            TextButton(
              onPressed: () => Get.to(() => const SignUpView()),
              child: CustomText(
                text: "NEW Account",
                textColor: Assets.shared.primaryColor,
                fontWeight: FontWeight.bold,
                isShowUnderline: true,
              ),
            ),
          ],
        ),
      ),
    );
  }
}