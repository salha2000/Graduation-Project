import 'package:car/utils/assets.dart';
import 'package:car/view/auth/sign_in_view.dart';
import 'package:car/view/widgets/custom_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

class SelectUserTypeView extends StatelessWidget {
  const SelectUserTypeView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            children: [
              SizedBox(
                height: 150.h,
              ),
              Image.asset(
                Assets.shared.icLogo,
                width: 259.w,
                height: 188.h,
              ),
            ],
          ),
          Column(
            children: [
              TextButton(
                onPressed: () => Get.to(() => const SignInView()),
                child: CustomText(
                  text: "User".toUpperCase(),
                  fontWeight: FontWeight.bold,
                  textColor: Assets.shared.primaryColor,
                ),
              ),
              SizedBox(height: 6.h,),
              CustomText(
                text: "or".toUpperCase(),
                fontWeight: FontWeight.bold,
                textColor: Assets.shared.primaryColor,
              ),
              SizedBox(height: 6.h,),
              TextButton(
                onPressed: () => Get.to(() => const SignInView()),
                child: CustomText(
                  text: "Driver".toUpperCase(),
                  fontWeight: FontWeight.bold,
                  textColor: Assets.shared.primaryColor,
                ),
              ),
              SizedBox(
                height: 188.h,
              ),
            ],
          ),
        ],
      ),
    );
  }
}